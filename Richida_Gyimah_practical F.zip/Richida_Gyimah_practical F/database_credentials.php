<?php

define ("SERVER_NAME", "localhost");
define ("USER_NAME", "root");
define ("PASSWORD", "");
define("DBNAME", "lab_post");

?>